/**
 * 防詐雷達 — Content Script v4
 * 支援新等級系統 + 綜合評分 + AI 卡片整合
 */

const API_BASE = 'https://l2y5p95avj.execute-api.ap-east-2.amazonaws.com/prod'
const CACHE_TTL = 60 * 60 * 1000

const CFG = {
  safe_high:    { label:'完全安全',         color:'#00C47A', border:'rgba(0,196,122,0.6)',   glow:'rgba(0,196,122,0.25)',  darkBg:'rgba(0,20,12,0.97)',    lightBg:'rgba(235,255,245,0.98)' },
  safe_low:     { label:'安全（低風險）',   color:'#5ddb9a', border:'rgba(93,219,154,0.5)',   glow:'rgba(93,219,154,0.2)',   darkBg:'rgba(0,18,10,0.97)',    lightBg:'rgba(240,255,248,0.98)' },
  suspect_low:  { label:'輕度可疑',         color:'#ffcc00', border:'rgba(255,204,0,0.6)',   glow:'rgba(255,204,0,0.25)',  darkBg:'rgba(20,18,0,0.97)',    lightBg:'rgba(255,252,220,0.98)' },
  suspect_high: { label:'高度可疑',         color:'#ff8800', border:'rgba(255,136,0,0.65)',  glow:'rgba(255,136,0,0.3)',   darkBg:'rgba(22,12,0,0.97)',    lightBg:'rgba(255,242,220,0.98)' },
  scam:         { label:'此為詐騙網站',     color:'#ff3d3d', border:'rgba(255,61,61,0.7)',   glow:'rgba(255,61,61,0.35)',  darkBg:'rgba(18,4,4,0.97)',     lightBg:'rgba(255,238,238,0.98)' },
  promo_safe:   { label:'行銷推廣（安全）', color:'#4d8ef5', border:'rgba(77,142,245,0.55)', glow:'rgba(77,142,245,0.2)', darkBg:'rgba(4,10,24,0.97)',    lightBg:'rgba(235,242,255,0.98)' },
  promo_warn:   { label:'行銷推廣（可疑）', color:'#ffcc00', border:'rgba(255,204,0,0.6)',   glow:'rgba(255,204,0,0.25)',  darkBg:'rgba(20,18,0,0.97)',    lightBg:'rgba(255,252,220,0.98)' },
  promo_scam:   { label:'行銷推廣（詐騙）', color:'#ff3d3d', border:'rgba(255,61,61,0.65)',  glow:'rgba(255,61,61,0.3)',   darkBg:'rgba(18,4,4,0.97)',     lightBg:'rgba(255,238,238,0.98)' },
  unknown:      { label:'查無資料',         color:'#a8c44e', border:'rgba(168,196,78,0.5)',  glow:'rgba(168,196,78,0.2)', darkBg:'rgba(10,15,4,0.97)',    lightBg:'rgba(245,250,235,0.98)' },
  // fallback
  safe:         { label:'安全無虞',         color:'#00C47A', border:'rgba(0,196,122,0.5)',   glow:'rgba(0,196,122,0.2)',  darkBg:'rgba(0,18,10,0.97)',    lightBg:'rgba(240,255,248,0.98)' },
  warn:         { label:'可疑內容',         color:'#ff8800', border:'rgba(255,136,0,0.6)',   glow:'rgba(255,136,0,0.28)', darkBg:'rgba(22,12,0,0.97)',    lightBg:'rgba(255,242,220,0.98)' },
  promo:        { label:'行銷推廣',         color:'#4d8ef5', border:'rgba(77,142,245,0.5)',  glow:'rgba(77,142,245,0.18)',darkBg:'rgba(4,10,24,0.97)',    lightBg:'rgba(235,242,255,0.98)' },
}

const IS_SAFE  = lv => ['safe','safe_high','safe_low','promo_safe'].includes(lv)
const IS_SCAM  = lv => ['scam','promo_scam'].includes(lv)
const IS_WARN  = lv => ['suspect_low','suspect_high','warn','promo_warn'].includes(lv)
const SHOW_CARD = lv => IS_SCAM(lv) || IS_WARN(lv) || lv === 'unknown'

let wrapEl = null

;(async () => {
  const hostname = location.hostname
  if (!hostname || location.href.startsWith('chrome') || hostname === 'localhost') return
  if (document.getElementById('fz-wrap')) return

  const settings = await new Promise(r => chrome.storage.local.get(['darkMode','autoCheck','showCard'], r))
  const darkMode  = settings.darkMode  !== false
  const autoCheck = settings.autoCheck !== false
  const showCard  = settings.showCard  !== false

  if (!autoCheck) return

  injectCapsule(darkMode)

  const cacheKey = `fz_cache_${hostname}`
  const cached = await getCache(cacheKey)
  if (cached) { render(cached, darkMode, showCard); return }

  try {
    const res = await fetch(`${API_BASE}/api/report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'llm', subtype: 'full', query: hostname, context: { queryType: 'url' } }),
    })
    const data = await res.json()
    await setCache(cacheKey, data)
    chrome.runtime.sendMessage({ type: 'SET_BADGE', level: data.level, score: data.score })
    render(data, darkMode, showCard)
  } catch (e) {
    wrapEl?.remove()
    console.warn('[防詐雷達]', e.message)
  }
})()

/* ══ 注入膠囊 ══ */
function injectCapsule(darkMode) {
  const wrap = document.createElement('div')
  wrap.id = 'fz-wrap'
  wrap.style.cssText = `
    all:initial; position:fixed; bottom:20px; right:20px; z-index:2147483647;
    font-family:-apple-system,'Noto Sans TC',sans-serif;
    display:flex; flex-direction:column; align-items:flex-end; gap:8px;
  `
  document.body.appendChild(wrap)
  wrapEl = wrap

  const capBg     = darkMode ? 'rgba(10,10,20,0.92)' : 'rgba(255,255,255,0.95)'
  const capBorder = darkMode ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.12)'
  const capShadow = darkMode ? '0.45' : '0.12'

  const cap = document.createElement('div')
  cap.id = 'fz-cap'
  cap.style.cssText = `
    display:flex; align-items:center; gap:7px;
    background:${capBg}; backdrop-filter:blur(20px);
    border:1.5px solid ${capBorder}; border-radius:100px;
    padding:7px 16px 7px 12px;
    box-shadow:0 4px 20px rgba(0,0,0,${capShadow});
    user-select:none; white-space:nowrap;
    opacity:0; transform:translateY(16px);
    transition:opacity 0.35s cubic-bezier(0.22,1,0.36,1),
               transform 0.35s cubic-bezier(0.22,1,0.36,1),
               border-color 0.3s, box-shadow 0.3s;
  `
  cap.innerHTML = `
    <span id="fz-dot" style="width:8px;height:8px;border-radius:50%;background:#888;flex-shrink:0;transition:all 0.4s;"></span>
    <span id="fz-icon" style="font-size:14px;line-height:1;"></span>
    <span id="fz-label" style="font-size:12px;font-weight:700;color:${darkMode?'#aaa':'#555'};">檢測中…</span>
  `
  wrap.appendChild(cap)
  requestAnimationFrame(() => requestAnimationFrame(() => {
    cap.style.opacity = '1'; cap.style.transform = 'translateY(0)'
  }))
}

/* ══ 渲染結果 ══ */
function render(data, darkMode, showCard) {
  const level = data.level ?? 'unknown'
  const cfg   = CFG[level] ?? CFG.warn
  const score = data.score ?? 0  // 綜合評分

  const cap   = document.getElementById('fz-cap')
  const dot   = document.getElementById('fz-dot')
  const icon  = document.getElementById('fz-icon')
  const label = document.getElementById('fz-label')

  const ICON_MAP = {
    safe_high:'✅', safe_low:'🟢', safe:'✅',
    suspect_low:'⚠️', suspect_high:'🟠', warn:'⚠️',
    scam:'🚨', promo_safe:'📣', promo_warn:'📣', promo_scam:'📣',
    unknown:'❓', promo:'📣',
  }

  if (dot)   { dot.style.background = cfg.color; dot.style.boxShadow = `0 0 7px ${cfg.glow}` }
  if (icon)  icon.textContent = ICON_MAP[level] ?? '❓'
  if (label) { label.textContent = cfg.label; label.style.color = cfg.color }
  if (cap)   {
    cap.style.borderColor = cfg.border
    cap.style.boxShadow = `0 4px 20px rgba(0,0,0,${darkMode?'0.45':'0.12'}), 0 0 12px ${cfg.glow}`
  }

  if (IS_SAFE(level)) {
    // safe：hover 按鈕，3秒後淡出
    attachHoverButtons(cap, cfg, darkMode)
    let isHovering = false
    let hideTimer = null

    function scheduleSafeHide(delay) {
      clearTimeout(hideTimer)
      hideTimer = setTimeout(() => {
        if (isHovering) return
        if (cap) { cap.style.opacity = '0'; cap.style.transform = 'translateY(16px)' }
        setTimeout(() => wrapEl?.remove(), 350)
      }, delay)
    }

    wrapEl.addEventListener('mouseenter', () => { isHovering = true; clearTimeout(hideTimer) })
    wrapEl.addEventListener('mouseleave', () => { isHovering = false; scheduleSafeHide(2000) })
    scheduleSafeHide(3000)

  } else if (level.startsWith('promo')) {
    // promo：hover 按鈕，持續
    attachHoverButtons(cap, cfg, darkMode)

  } else {
    // warn/scam/unknown：hover 按鈕 + 0.8秒展開卡片
    attachHoverButtons(cap, cfg, darkMode)
    if (showCard) setTimeout(() => expandCard(data, cfg, darkMode, score), 800)
  }
}

/* ══ Hover 快捷按鈕 ══ */
function attachHoverButtons(cap, cfg, darkMode) {
  if (!wrapEl) return

  const pillsWrap = document.createElement('div')
  pillsWrap.id = 'fz-pills'
  pillsWrap.style.cssText = `
    display:flex; flex-direction:column; align-items:flex-end; gap:6px;
    opacity:0; pointer-events:none;
    transition:opacity 0.2s ease, transform 0.2s ease;
    transform:translateY(6px);
  `

  const btnDefs = [
    { label:'🚫  一鍵封鎖', bg:'rgba(210,30,30,0.92)',  action:'block'  },
    { label:'📢  一鍵通報', bg:'rgba(190,110,0,0.92)',   action:'report' },
    { label:'📞  通報 165', bg:'rgba(45,71,232,0.92)',   action:'165'    },
  ]

  btnDefs.forEach(def => {
    const btn = document.createElement('button')
    btn.style.cssText = `
      background:${def.bg}; border:none; border-radius:100px;
      padding:8px 20px; color:#fff; font-size:13px; font-weight:800;
      cursor:pointer; font-family:-apple-system,'Noto Sans TC',sans-serif;
      white-space:nowrap; box-shadow:0 4px 14px rgba(0,0,0,0.35);
      display:flex; align-items:center; gap:6px; overflow:visible;
      transition:filter 0.12s, transform 0.12s;
    `
    // Split emoji and text
    const parts = def.label.split('  ')
    const emojiSpan = document.createElement('span')
    emojiSpan.style.cssText = 'font-size:15px;line-height:1;flex-shrink:0;'
    emojiSpan.textContent = parts[0]
    const textSpan = document.createElement('span')
    textSpan.textContent = parts[1]
    btn.appendChild(emojiSpan)
    btn.appendChild(textSpan)

    btn.addEventListener('mouseenter', () => {
      btn.style.filter = 'brightness(1.2)'
      btn.style.transform = 'scale(1.04) translateY(-2px)'
      btn.style.boxShadow = '0 8px 24px rgba(0,0,0,0.4)'
      btn.style.transition = 'all 0.15s cubic-bezier(0.22,1,0.36,1)'
    })
    btn.addEventListener('mouseleave', () => {
      btn.style.filter = ''
      btn.style.transform = ''
      btn.style.boxShadow = '0 4px 14px rgba(0,0,0,0.35)'
    })
    btn.addEventListener('mousedown', () => {
      btn.style.transform = 'scale(0.97) translateY(0)'
      btn.style.filter = 'brightness(0.9)'
    })
    btn.addEventListener('mouseup', () => {
      btn.style.transform = 'scale(1.04) translateY(-2px)'
      btn.style.filter = 'brightness(1.2)'
    })
    btn.addEventListener('click', e => {
      e.stopPropagation()
      if (def.action === '165') { window.open('https://165.npa.gov.tw/', '_blank') }
      else { doActionSimple(def.action, btn) }
    })
    pillsWrap.appendChild(btn)
  })

  wrapEl.insertBefore(pillsWrap, cap)

  let hideTimer = null
  function showPills() {
    clearTimeout(hideTimer)
    pillsWrap.style.opacity = '1'
    pillsWrap.style.pointerEvents = 'auto'
    pillsWrap.style.transform = 'translateY(0)'
  }
  function hidePills() {
    hideTimer = setTimeout(() => {
      pillsWrap.style.opacity = '0'
      pillsWrap.style.pointerEvents = 'none'
      pillsWrap.style.transform = 'translateY(6px)'
    }, 300)
  }

  cap.addEventListener('mouseenter', showPills)
  cap.addEventListener('mouseleave', hidePills)
  pillsWrap.addEventListener('mouseenter', () => { clearTimeout(hideTimer) })
  pillsWrap.addEventListener('mouseleave', hidePills)
}

/* ══ 展開卡片（含 AI 分析）══ */
function expandCard(data, cfg, darkMode, score) {
  const cap   = document.getElementById('fz-cap')
  const pills = document.getElementById('fz-pills')
  if (!cap || !wrapEl) return

  const hostname    = location.hostname
  const reasons     = data.reasons ?? data.ggl?.reasons ?? []
  const aiData      = data.ai ?? null
  const cardBg      = darkMode ? cfg.darkBg : cfg.lightBg
  const textMain    = darkMode ? '#fff'                   : '#111'
  const textSub     = darkMode ? 'rgba(255,255,255,0.42)' : 'rgba(0,0,0,0.38)'
  const urlBg       = darkMode ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.05)'
  const urlBorder   = darkMode ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.09)'
  const reasonClr   = darkMode ? 'rgba(255,255,255,0.72)' : 'rgba(0,0,0,0.7)'
  const closeBg     = darkMode ? 'rgba(255,255,255,0.1)'  : 'rgba(0,0,0,0.07)'
  const closeBdr    = darkMode ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.14)'
  const closeClr    = darkMode ? 'rgba(255,255,255,0.55)' : 'rgba(0,0,0,0.45)'
  const dividerClr  = darkMode ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)'
  const aiBg        = darkMode ? 'rgba(77,110,245,0.08)'  : 'rgba(77,110,245,0.05)'

  // 膠囊 + pills 縮小淡出
  pills?.remove()
  cap.style.transition = 'all 0.22s ease'
  cap.style.opacity = '0'
  cap.style.transform = 'translateY(10px) scale(0.88)'

  setTimeout(() => {
    if (!wrapEl) return
    cap.style.display = 'none'

    const card = document.createElement('div')
    card.id = 'fz-card'
    card.style.cssText = `
      width:300px; border-radius:18px;
      background:${cardBg}; backdrop-filter:blur(24px);
      border:1.5px solid ${cfg.border};
      box-shadow:0 12px 40px rgba(0,0,0,${darkMode?'0.6':'0.15'}), 0 0 30px ${cfg.glow};
      overflow:hidden;
      transform:translateY(28px); opacity:0;
      transition:transform 0.4s cubic-bezier(0.22,1,0.36,1), opacity 0.3s ease;
    `

    // AI 區塊 HTML（若有 AI 資料）
    const aiSection = aiData ? `
      <div style="margin-bottom:12px;padding:10px 12px;background:${aiBg};border-radius:10px;border:1px solid ${dividerClr};">
        <div style="font-size:10px;color:${cfg.color};font-weight:700;letter-spacing:0.5px;margin-bottom:6px;">🤖 AI 分析</div>
        ${aiData.fraud_type ? `<div style="font-size:11px;color:${textMain};font-weight:700;margin-bottom:4px;">🎯 ${aiData.fraud_type}</div>` : ''}
        ${aiData.suggestion ? `<div style="font-size:11px;color:${reasonClr};line-height:1.45;">💡 ${aiData.suggestion}</div>` : ''}
      </div>` : ''

    card.innerHTML = `
      <div style="height:3px;background:linear-gradient(90deg,transparent,${cfg.color},transparent);opacity:0.85;"></div>
      <div style="padding:15px 15px 13px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:11px;">
          <div style="display:flex;align-items:center;gap:9px;">
            <div>
              <div style="font-size:9px;color:${cfg.color};font-weight:700;letter-spacing:0.8px;text-transform:uppercase;">防詐雷達</div>
              <div style="font-size:14px;color:${textMain};font-weight:800;line-height:1.2;">${cfg.label}</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:6px;">
            <div style="background:${cfg.color}22;border:1.5px solid ${cfg.color}55;border-radius:100px;padding:3px 9px;font-size:12px;font-weight:800;color:${cfg.color};">${score}分</div>
            <button id="fz-close" style="
              background:${closeBg};border:1px solid ${closeBdr};
              border-radius:50%;width:24px;height:24px;color:${closeClr};
              font-size:12px;cursor:pointer;display:flex;align-items:center;justify-content:center;
              font-family:inherit;transition:background 0.15s;flex-shrink:0;
            ">✕</button>
          </div>
        </div>

        <div style="
          font-size:11px;color:${textSub};
          background:${urlBg};border:1px solid ${urlBorder};
          border-radius:8px;padding:5px 10px;margin-bottom:11px;
          overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:monospace;
        ">${hostname}</div>

        ${reasons.length ? `
        <div style="display:flex;flex-direction:column;gap:4px;margin-bottom:12px;">
          ${reasons.slice(0,2).map(r => `
            <div style="display:flex;gap:6px;align-items:flex-start;">
              <span style="color:${cfg.color};font-size:11px;flex-shrink:0;margin-top:2px;">•</span>
              <span style="font-size:11px;color:${reasonClr};line-height:1.45;">${r}</span>
            </div>`).join('')}
        </div>` : ''}

        ${aiSection}

        <div style="display:flex;flex-direction:column;gap:6px;">
          <div style="display:flex;gap:6px;">
            <button id="fz-btn-block" style="
              flex:1;padding:10px 4px;border-radius:10px;
              background:rgba(220,38,38,0.15);border:1.5px solid rgba(220,38,38,0.35);
              color:#ff5555;font-size:11px;font-weight:800;cursor:pointer;
              display:flex;flex-direction:column;align-items:center;gap:3px;
              font-family:inherit;transition:all 0.13s;line-height:1.3;
            "><span style="font-size:15px;">🚫</span><span>一鍵</span><span>封鎖</span></button>
            <button id="fz-btn-report" style="
              flex:1;padding:10px 4px;border-radius:10px;
              background:rgba(255,150,0,0.12);border:1.5px solid rgba(255,150,0,0.32);
              color:#ffaa00;font-size:11px;font-weight:800;cursor:pointer;
              display:flex;flex-direction:column;align-items:center;gap:3px;
              font-family:inherit;transition:all 0.13s;line-height:1.3;
            "><span style="font-size:15px;">📢</span><span>一鍵</span><span>通報</span></button>
            <button id="fz-btn-165" style="
              flex:1;padding:10px 4px;border-radius:10px;
              background:rgba(45,71,232,0.12);border:1.5px solid rgba(45,71,232,0.32);
              color:#7B9EFF;font-size:11px;font-weight:800;cursor:pointer;
              display:flex;flex-direction:column;align-items:center;gap:3px;
              font-family:inherit;transition:all 0.13s;line-height:1.3;
            "><span style="font-size:15px;">📞</span><span>通報</span><span>165</span></button>
          </div>
          <button id="fz-btn-leave" style="
            width:100%;padding:8px;border-radius:10px;
            background:rgba(0,196,122,0.1);border:1.5px solid rgba(0,196,122,0.28);
            color:#00C47A;font-size:12px;font-weight:800;cursor:pointer;
            display:flex;align-items:center;justify-content:center;gap:7px;
            font-family:inherit;transition:all 0.13s;box-sizing:border-box;
          "><span>←</span><span>離開此頁面</span></button>
        </div>
      </div>
    `

    wrapEl.appendChild(card)
    requestAnimationFrame(() => requestAnimationFrame(() => {
      card.style.transform = 'translateY(0)'; card.style.opacity = '1'
    }))

    card.querySelector('#fz-close')?.addEventListener('click', () => {
      card.style.transform = 'translateY(28px)'; card.style.opacity = '0'
      setTimeout(() => card.remove(), 400)
    })
    card.querySelector('#fz-btn-block')?.addEventListener('click', () => doActionBtn('block', card.querySelector('#fz-btn-block')))
    card.querySelector('#fz-btn-report')?.addEventListener('click', () => doActionBtn('report', card.querySelector('#fz-btn-report')))
    card.querySelector('#fz-btn-165')?.addEventListener('click', () => window.open('https://165.npa.gov.tw/', '_blank'))
    // 離開 → 開新分頁（chrome new tab）
    card.querySelector('#fz-btn-leave')?.addEventListener('click', () => chrome.runtime.sendMessage({ type: 'CLOSE_AND_NEWTAB' }))

    card.querySelectorAll('button').forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        btn.style.filter = 'brightness(1.25)'
        btn.style.transform = 'translateY(-2px) scale(1.02)'
        btn.style.boxShadow = `0 6px 20px rgba(0,0,0,0.35)`
        btn.style.transition = 'all 0.15s cubic-bezier(0.22,1,0.36,1)'
      })
      btn.addEventListener('mouseleave', () => {
        btn.style.filter = ''
        btn.style.transform = ''
        btn.style.boxShadow = ''
      })
      btn.addEventListener('mousedown', () => {
        btn.style.transform = 'translateY(0px) scale(0.97)'
        btn.style.filter = 'brightness(0.95)'
      })
      btn.addEventListener('mouseup', () => {
        btn.style.transform = 'translateY(-2px) scale(1.02)'
        btn.style.filter = 'brightness(1.25)'
      })
    })

  }, 240)
}

/* ══ 動作 ══ */
async function doActionBtn(type, btn) {
  try {
    await fetch(`${API_BASE}/api/report`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ type:'report', query: location.hostname, queryType:'url' }),
    })
    if (btn) {
      btn.innerHTML = '<span style="font-size:15px;">✅</span><span>已完成</span>'
      btn.disabled = true; btn.style.opacity = '0.6'
    }
  } catch {}
}

async function doActionSimple(type, btn) {
  try {
    await fetch(`${API_BASE}/api/report`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ type:'report', query: location.hostname, queryType:'url' }),
    })
    if (btn) { btn.childNodes[1].textContent = '✅ 已完成'; btn.disabled = true; btn.style.opacity = '0.7' }
  } catch {}
}

/* ══ 快取 ══ */
function getCache(key) {
  return new Promise(resolve => {
    chrome.storage.local.get(key, r => {
      const item = r[key]
      if (!item || Date.now() - item.ts > CACHE_TTL) return resolve(null)
      resolve(item.data)
    })
  })
}
function setCache(key, data) {
  return new Promise(resolve => chrome.storage.local.set({ [key]: { data, ts: Date.now() } }, resolve))
}

/* ══ 深淺色即時更新 ══ */
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return
  if (changes.autoCheck?.newValue === false) { wrapEl?.remove(); return }
  if (changes.showCard?.newValue === false)  { document.getElementById('fz-card')?.remove() }
  if (changes.darkMode) {
    const darkMode = changes.darkMode.newValue !== false
    const cap = document.getElementById('fz-cap')
    if (cap) {
      cap.style.background = darkMode ? 'rgba(10,10,20,0.92)' : 'rgba(255,255,255,0.95)'
      cap.style.borderColor = darkMode ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.12)'
    }
  }
})

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'REFRESH') {
    wrapEl?.remove()
    chrome.storage.local.remove(`fz_cache_${location.hostname}`)
    location.reload()
  }

  if (msg.type === 'UPDATE_RESULT') {
    // 不重新整理，直接更新膠囊和卡片
    const data = msg.data
    if (!data) return

    chrome.storage.local.get(['darkMode','showCard'], settings => {
      const darkMode = settings.darkMode !== false
      const showCard = settings.showCard !== false

      // 移除舊的 widget
      wrapEl?.remove()
      wrapEl = null

      // 重新注入
      injectCapsule(darkMode)
      render(data, darkMode, showCard)

      // 更新 badge
      chrome.runtime.sendMessage({ type: 'SET_BADGE', level: data.level, score: data.score })
    })
  }
})
