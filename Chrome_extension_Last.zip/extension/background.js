const BADGE = {
  safe_high:    { text: '✓',  color: '#00C47A' },
  safe_low:     { text: '✓',  color: '#00C47A' },
  safe:         { text: '✓',  color: '#00C47A' },
  suspect_low:  { text: '!',  color: '#ffcc00' },
  suspect_high: { text: '!!', color: '#ff8800' },
  warn:         { text: '!',  color: '#ff8800' },
  scam:         { text: '✕',  color: '#ff3d3d' },
  promo_safe:   { text: 'i',  color: '#4d8ef5' },
  promo_warn:   { text: '!',  color: '#ffcc00' },
  promo_scam:   { text: '✕',  color: '#ff3d3d' },
  promo:        { text: 'i',  color: '#4d8ef5' },
  unknown:      { text: '?',  color: '#a8c44e' },
  error:        { text: '?',  color: '#888888' },
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type !== 'SET_BADGE') return
  const tabId = sender.tab?.id
  if (!tabId) return
  const cfg = BADGE[msg.level] ?? BADGE.error
  chrome.action.setBadgeText({ text: cfg.text, tabId })
  chrome.action.setBadgeBackgroundColor({ color: cfg.color, tabId })
  if (['safe','safe_high','safe_low'].includes(msg.level)) {
    setTimeout(() => chrome.action.setBadgeText({ text: '', tabId }), 2000)
  }
})

chrome.runtime.onInstalled.addListener(() => {
  console.log('[防詐雷達] 已安裝')
})

// 開新分頁並關閉當前頁
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (msg.type === 'CLOSE_AND_NEWTAB') {
    const tabId = sender.tab?.id
    chrome.tabs.create({ url: 'chrome://newtab' }, () => {
      if (tabId) chrome.tabs.remove(tabId)
    })
  }
  if (msg.type === 'OPEN_NEWTAB') {
    chrome.tabs.create({ url: 'chrome://newtab' })
  }
})
