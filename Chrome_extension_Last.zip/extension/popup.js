const API_BASE = 'https://l2y5p95avj.execute-api.ap-east-2.amazonaws.com/prod'

const LEVEL_CFG = {
  safe_high:    { icon:'✅', label:'完全安全',         color:'#00C47A', bg:'rgba(0,196,122,0.12)'   },
  safe_low:     { icon:'🟢', label:'安全（低風險）',   color:'#5ddb9a', bg:'rgba(93,219,154,0.10)'  },
  safe:         { icon:'✅', label:'安全無虞',         color:'#00C47A', bg:'rgba(0,196,122,0.12)'   },
  suspect_low:  { icon:'⚠️', label:'輕度可疑',         color:'#ffcc00', bg:'rgba(255,204,0,0.12)'   },
  suspect_high: { icon:'🟠', label:'高度可疑',         color:'#ff8800', bg:'rgba(255,136,0,0.12)'   },
  warn:         { icon:'⚠️', label:'可疑內容',         color:'#ff8800', bg:'rgba(255,136,0,0.12)'   },
  scam:         { icon:'🚨', label:'此為詐騙內容',     color:'#ff3d3d', bg:'rgba(255,61,61,0.12)'   },
  promo_safe:   { icon:'📣', label:'行銷推廣（安全）', color:'#4d8ef5', bg:'rgba(77,142,245,0.12)'  },
  promo_warn:   { icon:'📣', label:'行銷推廣（可疑）', color:'#ffcc00', bg:'rgba(255,204,0,0.12)'   },
  promo_scam:   { icon:'📣', label:'行銷推廣（詐騙）', color:'#ff3d3d', bg:'rgba(255,61,61,0.12)'   },
  promo:        { icon:'📣', label:'行銷推廣',         color:'#4d8ef5', bg:'rgba(77,142,245,0.12)'  },
  unknown:      { icon:'❓', label:'查無資料',         color:'#a8c44e', bg:'rgba(168,196,78,0.12)'  },
}

let currentHostname = ''
let currentData = null

/* ── Tab 切換 ── */
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'))
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'))
    btn.classList.add('active')
    document.getElementById(`panel-${btn.dataset.tab}`)?.classList.add('active')
  })
})

/* ── Toggles ── */
function initToggles() {
  chrome.storage.local.get(['darkMode','autoCheck','showCard'], result => {
    const darkMode  = result.darkMode  ?? true
    const autoCheck = result.autoCheck ?? true
    const showCard  = result.showCard  ?? true
    setToggle('tog-dark',  darkMode)
    setToggle('tog-auto',  autoCheck)
    setToggle('tog-card',  showCard)
    if (!darkMode) document.body.classList.add('light')
  })
  bindToggle('tog-dark', 'darkMode', val => {
    document.body.classList.toggle('light', !val)
  })
  bindToggle('tog-auto', 'autoCheck')
  bindToggle('tog-card', 'showCard')
}

function setToggle(id, on) {
  document.getElementById(id)?.classList.toggle('on', on)
}
function bindToggle(id, key, cb) {
  const el = document.getElementById(id)
  if (!el) return
  el.addEventListener('click', () => {
    const isOn = el.classList.toggle('on')
    chrome.storage.local.set({ [key]: isOn })
    cb?.(isOn)
  })
}

/* ── 主查詢 ── */
async function init() {
  initToggles()
  chrome.storage.local.get('darkMode', r => {
    if (r.darkMode === false) document.body.classList.add('light')
  })

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.url) return
  try { currentHostname = new URL(tab.url).hostname } catch { return }

  document.getElementById('current-url').textContent = currentHostname
  document.getElementById('popup-wrap').className = 'popup-wrap'

  try {
    const data = await checkUrl(currentHostname)
    currentData = data
    renderResult(data)
    document.getElementById('popup-wrap').classList.add(`level-${data.level}`)
  } catch {
    document.getElementById('result-area').innerHTML =
      `<div style="font-size:11px;color:var(--text-muted);text-align:center;padding:8px 0;">❌ 查詢失敗</div>`
  }

  document.getElementById('btn-report')?.addEventListener('click', () => doAction('report', 'btn-report'))
  document.getElementById('btn-165')?.addEventListener('click', () => window.open('https://165.npa.gov.tw/', '_blank'))
  document.getElementById('btn-block')?.addEventListener('click', () => doAction('block', 'btn-block'))
  document.getElementById('btn-refresh')?.addEventListener('click', async () => {
    // 1. 清快取
    chrome.storage.local.remove(`fz_cache_${currentHostname}`)

    // 2. 顯示載入中
    document.getElementById('result-area').innerHTML =
      `<div class="loading"><div class="spinner"></div>重新查詢中…</div>`
    document.getElementById('popup-wrap').className = 'popup-wrap'

    try {
      // 3. 重新查詢（不 reload 頁面）
      const data = await checkUrl(currentHostname)
      currentData = data
      renderResult(data)
      document.getElementById('popup-wrap').classList.add(`level-${data.level}`)

      // 4. 通知 content script 更新膠囊/卡片（不重新整理頁面）
      const [t] = await chrome.tabs.query({ active: true, currentWindow: true })
      if (t?.id) {
        chrome.tabs.sendMessage(t.id, {
          type: 'UPDATE_RESULT',
          data,
        }).catch(() => {})
      }
    } catch {
      document.getElementById('result-area').innerHTML =
        `<div style="font-size:11px;color:var(--text-muted);text-align:center;padding:8px 0;">❌ 查詢失敗，請稍後再試</div>`
    }
  })
}

async function checkUrl(hostname) {
  const cacheKey = `fz_cache_${hostname}`
  const cached = await new Promise(resolve => {
    chrome.storage.local.get(cacheKey, result => {
      const item = result[cacheKey]
      if (!item || Date.now() - item.ts > 3600000) return resolve(null)
      resolve(item.data)
    })
  })
  if (cached) return cached

  const res = await fetch(`${API_BASE}/api/report`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'llm', subtype: 'full', query: hostname, context: { queryType: 'url' } }),
  })
  const data = await res.json()
  chrome.storage.local.set({ [cacheKey]: { data, ts: Date.now() } })
  return data
}

async function doAction(type, btnId) {
  try {
    await fetch(`${API_BASE}/api/report`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'report', query: currentHostname, queryType: 'url' }),
    })
    const btn = document.getElementById(btnId)
    if (btn) {
      const icon  = btn.querySelector('.act-icon')
      const label = btn.querySelector('.act-label')
      if (icon)  icon.textContent  = '✅'
      if (label) label.textContent = '已完成'
      btn.disabled = true; btn.style.opacity = '0.6'
    }
  } catch {}
}

function renderResult(data) {
  const level  = data.level ?? 'unknown'
  const score  = data.score ?? 0   // 綜合評分
  const cfg    = LEVEL_CFG[level] ?? LEVEL_CFG.unknown
  const reasons = data.reasons ?? data.ggl?.reasons ?? []
  const aiData  = data.ai ?? null
  const gglScore = data.ggl?.score ?? null
  const aiScore  = data.ai?.score  ?? null

  document.getElementById('result-area').innerHTML = `
    <!-- 綜合評分 -->
    <div class="result-row">
      <div class="result-badge">
        <span style="font-size:18px;">${cfg.icon}</span>
        <span style="color:${cfg.color};font-size:13px;">${cfg.label}</span>
      </div>
      <div class="score-chip" style="background:${cfg.bg};color:${cfg.color};border:1px solid ${cfg.color}44;">
        ${score} 分
      </div>
    </div>

    <!-- Gogolook / AI 個別分數 -->
    ${(gglScore !== null || aiScore !== null) ? `
    <div style="display:flex;gap:8px;margin-top:6px;margin-bottom:2px;">
      ${gglScore !== null ? `<span style="font-size:10px;color:var(--text-muted);background:var(--surface);border:1px solid var(--border);border-radius:100px;padding:2px 8px;">Gogolook ${gglScore}</span>` : ''}
      ${aiScore  !== null ? `<span style="font-size:10px;color:var(--text-muted);background:var(--surface);border:1px solid var(--border);border-radius:100px;padding:2px 8px;">AI ${aiScore}</span>` : ''}
    </div>` : ''}

    <!-- 分析原因 -->
    ${reasons.length ? `
    <div class="reasons">
      ${reasons.slice(0,3).map((r,i) => `
        <div class="reason-item" style="animation-delay:${0.08+i*0.04}s">
          <span style="color:${cfg.color};flex-shrink:0;">•</span>
          <span>${r}</span>
        </div>`).join('')}
    </div>` : ''}

    <!-- AI 分析 -->
    ${aiData?.suggestion ? `
    <div style="margin-top:8px;padding:8px 10px;background:rgba(77,110,245,0.08);border:1px solid rgba(77,110,245,0.15);border-radius:8px;">
      <div style="font-size:9px;color:#7B9EFF;font-weight:700;margin-bottom:4px;">🤖 AI 分析</div>
      ${aiData.fraud_type ? `<div style="font-size:11px;font-weight:700;color:var(--text);margin-bottom:3px;">🎯 ${aiData.fraud_type}</div>` : ''}
      <div style="font-size:11px;color:var(--text-sub);line-height:1.4;">💡 ${aiData.suggestion}</div>
    </div>` : ''}
  `
}

init()
