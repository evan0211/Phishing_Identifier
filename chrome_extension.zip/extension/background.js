// 防詐雷達 background service worker
// 目前保留供未來擴充使用（如 badge 計數、通知等）

chrome.runtime.onInstalled.addListener(() => {
  console.log('[防詐雷達] 擴充套件已安裝')
})
