/**
 * 防詐雷達 — Content Script
 * 注入每個網頁，自動查詢當前網址的風險等級
 */

const API_BASE = 'https://l2y5p95avj.execute-api.ap-east-2.amazonaws.com/prod'
const CACHE_TTL = 60 * 60 * 1000 // 1小時快取

;(async () => {
  const url = location.href
  const hostname = location.hostname

  // 跳過空白頁、擴充套件頁、本機
  if (!hostname || hostname === 'newtab' || url.startsWith('chrome') || url.startsWith('about') || hostname === 'localhost') return

  // 避免重複注入
  if (document.getElementById('fangzha-radar-widget')) return

  // 查本地快取
  const cacheKey = `fz_cache_${hostname}`
  const cached = await getCache(cacheKey)
  if (cached) {
    if (cached.level !== 'safe') showWidget(cached, hostname)
    return
  }

  // 呼叫 Lambda API
  try {
    const res = await fetch(`${API_BASE}/api/check/url`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ type: 'url', query: hostname }),
    })
    const data = await res.json()
    await setCache(cacheKey, data)
    if (data.level && data.level !== 'safe') {
      showWidget(data, hostname)
    } else {
      showSafeDot()
    }
  } catch (e) {
    console.warn('[防詐雷達] API 連線失敗', e)
  }
})()

/* ── 快取 ── */
function getCache(key) {
  return new Promise(resolve => {
    chrome.storage.local.get(key, result => {
      const item = result[key]
      if (!item) return resolve(null)
      if (Date.now() - item.ts > CACHE_TTL) return resolve(null)
      resolve(item.data)
    })
  })
}

function setCache(key, data) {
  return new Promise(resolve => {
    chrome.storage.local.set({ [key]: { data, ts: Date.now() } }, resolve)
  })
}

/* ── 安全小綠點 ── */
function showSafeDot() {
  const dot = document.createElement('div')
  dot.id = 'fangzha-radar-widget'
  dot.style.cssText = `
    position: fixed; bottom: 16px; right: 16px; z-index: 2147483647;
    width: 10px; height: 10px; border-radius: 50%;
    background: #00C47A; box-shadow: 0 0 0 3px rgba(0,196,122,0.25);
    pointer-events: none; transition: opacity 0.3s;
  `
  document.body.appendChild(dot)
  setTimeout(() => { dot.style.opacity = '0' }, 3000)
  setTimeout(() => dot.remove(), 3300)
}

/* ── 警告 Widget ── */
function showWidget(data, hostname) {
  const { level, score, label, reasons = [] } = data

  const colors = {
    scam:  { bg: '#1a0505', border: '#ff3d3d', accent: '#ff3d3d', badge: '#ff3d3d', text: '#fff' },
    warn:  { bg: '#1a1005', border: '#ffaa00', accent: '#ffaa00', badge: '#ffaa00', text: '#fff' },
    promo: { bg: '#0a0a1a', border: '#7B9EFF', accent: '#7B9EFF', badge: '#7B9EFF', text: '#fff' },
    unknown: { bg: '#0f1a05', border: '#a8c44e', accent: '#a8c44e', badge: '#a8c44e', text: '#fff' },
  }
  const c = colors[level] ?? colors.warn

  const icons = { scam: '🚨', warn: '⚠️', promo: '📣', unknown: '❓' }
  const icon = icons[level] ?? '⚠️'

  const topReasons = reasons.slice(0, 2)

  const widget = document.createElement('div')
  widget.id = 'fangzha-radar-widget'
  widget.innerHTML = `
    <div id="fz-main" style="
      position: fixed; bottom: 20px; right: 20px; z-index: 2147483647;
      width: 320px; border-radius: 16px;
      background: ${c.bg}; border: 1.5px solid ${c.border};
      box-shadow: 0 8px 32px rgba(0,0,0,0.5), 0 0 0 1px ${c.border}33;
      font-family: -apple-system, 'Noto Sans TC', sans-serif;
      overflow: hidden; transition: all 0.3s cubic-bezier(0.22,1,0.36,1);
      transform: translateY(20px); opacity: 0;
    ">
      <!-- 頂部色條 -->
      <div style="height: 3px; background: ${c.accent}; width: 100%;"></div>

      <!-- 主體 -->
      <div style="padding: 14px 16px 12px;">
        <!-- 標題列 -->
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 10px;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 18px;">${icon}</span>
            <div>
              <div style="font-size: 11px; color: ${c.accent}; font-weight: 700; letter-spacing: 0.5px;">防詐雷達</div>
              <div style="font-size: 13px; color: #fff; font-weight: 700; line-height: 1.2;">${label}</div>
            </div>
          </div>
          <div style="display: flex; align-items: center; gap: 6px;">
            <div style="
              background: ${c.badge}22; border: 1px solid ${c.badge}66;
              border-radius: 100px; padding: 2px 8px;
              font-size: 11px; font-weight: 700; color: ${c.accent};
            ">${score}分</div>
            <button id="fz-close" style="
              background: rgba(255,255,255,0.08); border: none; border-radius: 50%;
              width: 22px; height: 22px; color: rgba(255,255,255,0.5);
              font-size: 12px; cursor: pointer; display: flex; align-items: center; justify-content: center;
            ">✕</button>
          </div>
        </div>

        <!-- 網址 -->
        <div style="
          font-size: 11px; color: rgba(255,255,255,0.4);
          background: rgba(255,255,255,0.05); border-radius: 6px;
          padding: 4px 8px; margin-bottom: 10px;
          white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
        ">${hostname}</div>

        <!-- 風險原因 -->
        ${topReasons.length ? `
        <div style="display: flex; flex-direction: column; gap: 5px; margin-bottom: 12px;">
          ${topReasons.map(r => `
            <div style="
              font-size: 11px; color: rgba(255,255,255,0.7);
              display: flex; align-items: flex-start; gap: 6px;
            ">
              <span style="color: ${c.accent}; flex-shrink: 0;">•</span>
              <span>${r}</span>
            </div>
          `).join('')}
        </div>` : ''}

        <!-- 按鈕列 -->
        <div style="display: flex; gap: 8px;">
          <button id="fz-report" style="
            flex: 1; background: ${c.accent}22; border: 1px solid ${c.accent}66;
            border-radius: 8px; padding: 7px; color: ${c.accent};
            font-size: 11px; font-weight: 700; cursor: pointer;
          ">🚩 回報</button>
          <button id="fz-leave" style="
            flex: 1; background: rgba(0,196,122,0.15); border: 1px solid rgba(0,196,122,0.4);
            border-radius: 8px; padding: 7px; color: #00C47A;
            font-size: 11px; font-weight: 700; cursor: pointer;
          ">← 離開此頁</button>
        </div>
      </div>
    </div>
  `

  document.body.appendChild(widget)

  // 入場動畫
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      const main = document.getElementById('fz-main')
      if (main) { main.style.transform = 'translateY(0)'; main.style.opacity = '1' }
    })
  })

  // 關閉按鈕
  document.getElementById('fz-close')?.addEventListener('click', () => {
    const main = document.getElementById('fz-main')
    if (main) { main.style.transform = 'translateY(20px)'; main.style.opacity = '0' }
    setTimeout(() => widget.remove(), 300)
  })

  // 回報按鈕
  document.getElementById('fz-report')?.addEventListener('click', async () => {
    try {
      await fetch(`${API_BASE}/api/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'report', query: hostname, queryType: 'url' }),
      })
      const btn = document.getElementById('fz-report')
      if (btn) { btn.textContent = '✅ 已回報'; btn.disabled = true }
    } catch {}
  })

  // 離開按鈕
  document.getElementById('fz-leave')?.addEventListener('click', () => {
    history.back()
  })
}
