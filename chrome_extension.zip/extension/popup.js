const API_BASE = 'https://l2y5p95avj.execute-api.ap-east-2.amazonaws.com/prod'

const LEVEL_CONFIG = {
  safe:    { icon: '✅', label: '安全無虞',      color: '#00C47A', bg: 'rgba(0,196,122,0.15)'  },
  promo:   { icon: '📣', label: '行銷推廣內容',  color: '#7B9EFF', bg: 'rgba(123,158,255,0.15)' },
  warn:    { icon: '⚠️', label: '可疑內容，請謹慎', color: '#ffaa00', bg: 'rgba(255,170,0,0.15)'  },
  scam:    { icon: '🚨', label: '此為詐騙內容',  color: '#ff3d3d', bg: 'rgba(255,61,61,0.15)'   },
  unknown: { icon: '❓', label: '查無資料',       color: '#a8c44e', bg: 'rgba(168,196,78,0.15)'  },
}

async function checkUrl(hostname) {
  // 先查快取
  const cacheKey = `fz_cache_${hostname}`
  const cached = await new Promise(resolve => {
    chrome.storage.local.get(cacheKey, result => {
      const item = result[cacheKey]
      if (!item) return resolve(null)
      if (Date.now() - item.ts > 3600000) return resolve(null)
      resolve(item.data)
    })
  })
  if (cached) return cached

  const res = await fetch(`${API_BASE}/api/check/url`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ type: 'url', query: hostname }),
  })
  const data = await res.json()

  chrome.storage.local.set({ [cacheKey]: { data, ts: Date.now() } })
  return data
}

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true })
  if (!tab?.url) return

  let hostname
  try {
    hostname = new URL(tab.url).hostname
  } catch {
    document.getElementById('current-url').textContent = '無法解析網址'
    document.getElementById('result-area').innerHTML = ''
    return
  }

  document.getElementById('current-url').textContent = hostname

  try {
    const data = await checkUrl(hostname)
    renderResult(data)
  } catch (e) {
    document.getElementById('result-area').innerHTML = `
      <div style="font-size:11px;color:rgba(255,255,255,0.4);text-align:center;padding:8px 0;">
        ❌ 查詢失敗，請確認網路連線
      </div>`
  }

  // 回報按鈕
  document.getElementById('btn-report')?.addEventListener('click', async () => {
    try {
      await fetch(`${API_BASE}/api/report`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: 'report', query: hostname, queryType: 'url' }),
      })
      const btn = document.getElementById('btn-report')
      if (btn) { btn.textContent = '✅ 已回報'; btn.disabled = true }
    } catch {}
  })

  // 重新查詢按鈕
  document.getElementById('btn-check')?.addEventListener('click', async () => {
    chrome.storage.local.remove(`fz_cache_${hostname}`)
    document.getElementById('result-area').innerHTML = `
      <div class="loading"><div class="spinner"></div>查詢中…</div>`
    try {
      const data = await checkUrl(hostname)
      renderResult(data)
    } catch {}
  })
}

function renderResult(data) {
  const { level, score, reasons = [] } = data
  const cfg = LEVEL_CONFIG[level] ?? LEVEL_CONFIG.warn
  const topReasons = reasons.slice(0, 3)

  document.getElementById('result-area').innerHTML = `
    <div class="result-row">
      <div class="result-badge">
        <span>${cfg.icon}</span>
        <span style="color:${cfg.color}">${cfg.label}</span>
      </div>
      <div class="score-chip" style="background:${cfg.bg};color:${cfg.color};border:1px solid ${cfg.color}44;">
        ${score} 分
      </div>
    </div>
    ${topReasons.length ? `
    <div class="reasons">
      ${topReasons.map(r => `
        <div class="reason-item">
          <span class="reason-dot" style="color:${cfg.color}">•</span>
          <span>${r}</span>
        </div>`).join('')}
    </div>` : ''}
  `
}

init()
